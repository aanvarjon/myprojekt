// 2 .Foydalanuvchi biror son kiritsa shuncha 
// fibonachchi numberni chiqaradigan fnuksiya yozing.

// function fibonacci(n) {
//     let fib = [0, 1];
//     for (let i = 2; i < n; i++) {
//         fib[i] = fib[i - 1] + fib[i - 2];
//     }
//     return fib;
// }

// const result = fibonacci(12);
// console.log(result); 

// 3. Ketma-ket sonlardan tashkil topgan Array berilgan.
//  uni ichidan unutib qoldirilgan raqamni topuvchi funksiya yozing.

// function findMissingNumber(arr) {
//     let sum = arr.reduce((acc, curr) => acc + curr, 0)
//     let n = arr.length + 1
//     let totalSum = (n * (n + 1)) / 2
//     return totalSum - sum
// }

// const numbers = [1, 2, 4, 5, 6]
// const missingNumber = findMissingNumber(numbers)
// console.log(missingNumber) 

// 4. Berilgan arrayni nechtadir sonini chapdan o'ngga yozib beruvchi funksiya yozing. 

// function rotateLeft(arr, n) {
//     n = n % arr.length
//     return [...arr.slice(n), ...arr.slice(0, n)]
// }

// const numbers = [1, 2, 3, 4, 5]
// const rotatedNumbers = rotateLeft(numbers, 4)
// console.log(rotatedNumbers) 
